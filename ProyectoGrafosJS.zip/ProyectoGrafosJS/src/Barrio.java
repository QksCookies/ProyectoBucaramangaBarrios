public class Barrio {
    String nombreBarrio;

    public Barrio(String nombreBarrio, double distancia) {
        this.nombreBarrio = nombreBarrio;
    }
    public Barrio(String nombreBarrio) {
        this.nombreBarrio = nombreBarrio;
    }

    public String getNombreBarrio() {
        return nombreBarrio;
    }
}
