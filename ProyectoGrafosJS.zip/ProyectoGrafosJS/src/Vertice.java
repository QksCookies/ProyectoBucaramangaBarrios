public class Vertice {
    Barrio barrio;

    public Vertice(Barrio barrio) {
        this.barrio = barrio;
    }

    public Barrio getBarrio() {
        return barrio;
    }
}
